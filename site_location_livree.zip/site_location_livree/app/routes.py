
from flask import Blueprint, render_template, request, redirect, url_for, session
from . import db
from .models import Livre, Location

main = Blueprint('main', __name__)


def seed_data():
    if not Livre.query.first():
        livres = [
            Livre(titre="Le Petit Prince", image="le_petit_prince.jpg", prix=7000, stock=5),
            Livre(titre="1984", image="1984.jpg", prix=12000, stock=3),
            Livre(titre="Les Misérables", image="les_miserables.jpg", prix=15000, stock=4),
            Livre(titre="Harry Potter", image="harry_potter.jpg", prix=10000, stock=6),
            Livre(titre="L'Étranger", image="etranger.jpg", prix=9000, stock=6),
        ]
        db.session.bulk_save_objects(livres)
        db.session.commit() 

@main.route("/")
def index():
    livres = Livre.query.all()
    return render_template("index.html", livres=livres)

@main.route("/louer/<int:livre_id>", methods=["POST"])
def louer(livre_id):
    livre = Livre.query.get_or_404(livre_id)
    nom = request.form.get("nom")
    telephone = request.form.get("telephone")
    quantite = int(request.form.get("quantite", 1))

    if livre.stock >= quantite:
        location = Location(nom=nom, telephone=telephone, livre_id=livre.id, quantite=quantite)
        db.session.add(location)
        livre.stock -= quantite
        db.session.commit()

        panier = session.get("panier", [])
        panier.append({"titre": livre.titre, "quantite": quantite, "prix": livre.prix, "image": livre.image})
        session["panier"] = panier

    return redirect(url_for("main.index"))

@main.route("/panier")
def panier():
    panier = session.get("panier", [])
    total = sum(item["quantite"] * item["prix"] for item in panier)
    return render_template("panier.html", panier=panier, total=total)
