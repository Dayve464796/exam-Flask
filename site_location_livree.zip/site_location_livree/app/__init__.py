
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from .models import db
from .routes import main, seed_data

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'votre_cle_secrete'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///livres.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    db.init_app(app)
    app.register_blueprint(main)

    with app.app_context():
        db.create_all()
        seed_data()  # Appel ici avec le bon contexte

    return app