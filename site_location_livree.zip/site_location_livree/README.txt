
Projet Flask : Site de Location de Livres

Description :
Ce projet est un site web de location de livres et romans. L’utilisateur peut :
- Consulter une liste de livres avec image, nom et prix (en Franc CFA).
- Louer un livre en remplissant un formulaire.
- Voir son panier avec le résumé des livres loués, le prix unitaire et le total.
- Être notifié si un livre est en rupture de stock.

Fonctionnalités :
- Base de données SQLite pour stocker les livres et les locations.
- Interface utilisateur avec Bootstrap.
- Images des livres affichées et fond personnalisé.
- Système de panier stocké en session.

Structure :
- app/
    - __init__.py
    - models.py
    - routes.py
    - templates/
        - index.html
        - panier.html
    - static/
        - images/
        - css/
- run.py
- requirements.txt

Instructions :
1. Créer un environnement virtuel :
   python -m venv env
   source env/bin/activate (Linux/Mac) ou env\Scripts\activate (Windows)

2. Installer les dépendances :
   pip install -r requirements.txt

3. Lancer l'application :
   python run.py

L’application sera accessible sur http://127.0.0.1:5000/
